TinyRavProgram / AUTH
README
======

(you can see "```" in the txt, its just a glitch. you can read it as a empty paragraph.)

1. WHAT IS TINYRAVPROGRAM?

---

TinyRavProgram is a small Windows program designed to run files written
in the custom AUTH scripting language.

AUTH is intentionally simple and lightweight. It is designed so that
programs can be written directly in Notepad without requiring HTML, CSS,
JavaScript, Python, or another large language.

AUTH files use the extension:

```
.auth
```

## 2. WHAT IS AUTH?

AUTH is the custom scripting language interpreted by TinyRavProgram.

A basic AUTH program can look like this:

```
var x = 10 ;
var y = 5 ;
var amogus = sus ;

say var-x + var-y ;
say var-amogus ;
```

The semicolon (;) ends a command.

Variables are created with "var".

The "var-" prefix is used when referring to a variable.

The "say" command displays a result.

AUTH can store numbers, quoted text, and simple unquoted text values.

3. BASIC SYNTAX

---

Create a numeric variable:

```
var x = 10 ;
```

Create another variable:

```
var y = 5 ;
```

Create a text variable:

```
var name = "RavKo" ;
```

Create an unquoted text value:

```
var amogus = sus ;
```

Use variables:

```
say var-x + var-y ;
say var-name ;
say var-amogus ;
```

## 4. TEXT AND VALUES

AUTH supports numeric values, quoted text, and simple unquoted text.

Number:

```
var number = 25 ;
```

Quoted text:

```
var name = "RavKo" ;
```

Unquoted text:

```
var word = hello ;
```

Display a variable:

```
say var-name ;
say var-word ;
```

Combine text:

```
say "Hello " + var-name ;
```

Combine numeric values:

```
var x = 10 ;
var y = 5 ;

say var-x + var-y ;
```

Numeric expressions are added mathematically when all parts are numbers.
Text expressions are combined as text.

5. SAY

---

The "say" command displays an AUTH result in a message box.

Examples:

```
say "Hello from AUTH!" ;

var name = "RavKo" ;
say var-name ;

var x = 10 ;
var y = 5 ;
say var-x + var-y ;

var amogus = sus ;
say var-amogus ;
```

## 6. WINDOWS

AUTH can create a simple program window.

Example:

```
CreateWindow {
    W="300"
    H="300"
    TITLE="My AUTH Program"
    RESIZABLE="false"
    TRAYICON="false"
    EXTENSIONS="false"
}
```

W = window width.

H = window height.

TITLE = window title.

RESIZABLE = whether the window can be resized.

TRAYICON = reserved for future tray functionality.

EXTENSIONS = enables additional AUTH interface features.

7. EXTENSIONS

---

When EXTENSIONS is enabled, interface elements such as Text and Button
can be used.

Example:

```
CreateWindow {
    W="400"
    H="250"
    TITLE="AUTH Test"
    RESIZABLE="true"
    TRAYICON="false"
    EXTENSIONS="true"
}

Text {
    X="20"
    Y="20"
    W="350"
    H="30"
    TEXT="Hello from AUTH!"
}

Button {
    X="20"
    Y="70"
    W="120"
    H="30"
    TEXT="Click me"
}
```

Text creates a text element.

Button creates a clickable button.

The current Button handler displays a built-in TinyRavProgram message.

8. COMMENTS

---

Lines beginning with ";" are treated as comments.

Example:

```
; This is a comment
var x = 10 ;
```

Comments are ignored by the AUTH interpreter.

9. HOW TO USE AUTH

---

1. Open Notepad.
2. Write an AUTH program.
3. Save the file with the .auth extension.
4. Open TinyRavProgram.
5. Press "Run .auth".
6. Select the .auth file.
7. TinyRavProgram reads and interprets the AUTH commands.

TinyRavProgram can also register the .auth file extension with Windows.

When the file association is registered, opening an .auth file can launch
TinyRavProgram directly and pass the selected AUTH file to the interpreter.

AUTH files remain normal editable text files.

10. TINYRAVPROGRAM SOURCE FOLDER

---

On startup, TinyRavProgram creates a folder in Documents:

```
Documents\
└── TinyRavProgram_src\
    ├── TinyRavProgram.db
    ├── README.bat
    ├── README.txt
    ├── TinyRavProgram.ahk
    └── example.auth
```

TinyRavProgram.db contains basic program information.

README.bat is a small command-line information file.

README.txt contains the main project documentation.

TinyRavProgram.ahk is the AutoHotkey source code used to build the program.

example.auth is an example AUTH program.

11. EXAMPLE PROGRAM

---

The following is a complete small AUTH example:

```
var name = "RavKo" ;
var x = 10 ;
var y = 5 ;
var amogus = sus ;

say "Hello " + var-name ;
say var-x + var-y ;
say var-amogus ;
```

It demonstrates variables, text, numbers, unquoted text values,
expressions, and the say command.

12. HOW AUTH WAS CREATED

---

AUTH was created as a custom scripting-language idea for TinyRavProgram.

It was not discovered as an existing mainstream programming language.

The goal was to make a language that feels like a real programming
language while remaining small enough to understand and write manually.

The original idea started with very simple commands such as:

```
var x = 10 ;
var y = 5 ;
say var-x + var-y ;
```

The language was then expanded with variables containing text,
CreateWindow, Text, Button, and optional interface extensions.

The name AUTH refers to the custom scripting language and .auth file
format used by TinyRavProgram. It is not intended to claim compatibility
with another existing AUTH language.

13. DESIGN GOALS

---

AUTH is designed around these ideas:

* Simple syntax
* Lightweight interpreter
* Easy editing in Notepad
* Small programs
* No HTML requirement
* No CSS requirement
* No JavaScript requirement
* No Python requirement
* Easy-to-read commands
* Custom Windows program integration
* Editable plain-text source files

14. CURRENT LIMITATIONS

---

AUTH is currently a small interpreter rather than a full programming
language.

Only commands implemented by the current TinyRavProgram interpreter
are supported.

Current supported language features include:

* var
* say
* CreateWindow
* Text
* Button
* * expressions
* comments beginning with ;

The Button extension currently uses the built-in TinyRavProgram handler.

TRAYICON is currently reserved and does not create a custom tray icon.

Advanced programming features such as loops, conditions, functions,
arrays, file APIs, and custom event handlers are not currently part of
the language.

15. FILE EXTENSION

---

AUTH programs use:

```
.auth
```

Example:

```
hello.auth
```

TinyRavProgram can register the .auth extension with Windows.

After registration, an .auth file can be opened through TinyRavProgram,
depending on the Windows file-association settings.

AUTH files are plain-text files and can still be edited with Notepad or
another text editor.

16. PROJECT STATUS

---

Project: TinyRavProgram
Language: AUTH
Platform: Windows
Main source language: AutoHotkey v1
AUTH interpreter: TinyRavProgram
Current version: 1.1

This project is experimental and is being developed as a lightweight
custom scripting environment.

17. QUICK START

---

Create a file named:

```
hello.auth
```

Put this inside:

```
say "Hello from AUTH!" ;
```

Save it.

Open TinyRavProgram.

Press:

```
Run .auth
```

Select hello.auth.

TinyRavProgram will interpret the command and display the message.

A slightly larger example:

```
var name = "RavKo" ;
var amogus = sus ;

say "Hello " + var-name ;
say var-amogus ;
```

==============================
End of README
TinyRavProgram / AUTH
=====================
