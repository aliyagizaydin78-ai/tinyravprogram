﻿#NoTrayIcon
#SingleInstance Force
#NoEnv

SrcFolder := A_MyDocuments . "\TinyRavProgram_src"

if !FileExist(SrcFolder)
    FileCreateDir, %SrcFolder%

DBFile := SrcFolder . "\TinyRavProgram.db"
BATFile := SrcFolder . "\README.bat"
READMEFile := SrcFolder . "\README.txt"
AUTHFile := SrcFolder . "\example.auth"
AHKFile := SrcFolder . "\TinyRavProgram.ahk"


if !FileExist(DBFile)
{
    DBText =
    (
[TinyRavProgram]
Version=1.1
Language=AUTH
SourceFolder=%SrcFolder%
    )

    FileAppend, %DBText%, %DBFile%, UTF-8
}


if !FileExist(BATFile)
{
    BATText =
    (
@echo off
title TinyRavProgram
echo.
echo ================================
echo        TinyRavProgram
echo ================================
echo.
echo README.txt contains documentation.
echo AUTH is the scripting language used by TinyRavProgram.
echo.
pause
    )

    FileAppend, %BATText%, %BATFile%, UTF-8
}


if !FileExist(READMEFile)
{
    READMEText =
    (
TinyRavProgram / AUTH
README
==============================

TinyRavProgram is a small Windows program designed to run files written
in the custom AUTH scripting language.

AUTH files use the .auth extension.

Basic example:

    var x = 10 ;
    var y = 5 ;
    var amogus = sus ;

    say var-x + var-y ;
    say var-amogus ;

AUTH is intentionally simple and lightweight.
    )

    FileAppend, %READMEText%, %READMEFile%, UTF-8
}


if !FileExist(AHKFile)
{
    AHKText =
    (
; TinyRavProgram source
; This file is stored in TinyRavProgram_src.
; TinyRavProgram.exe is the compiled program.
    )

    FileAppend, %AHKText%, %AHKFile%, UTF-8
}


if !FileExist(AUTHFile)
{
    AUTHText =
    (
; TinyRavProgram AUTH example

var x = 10 ;
var y = 5 ;
var amogus = sus ;
var name = "RavKo" ;

say var-x + var-y ;
say var-amogus ;
say "Hello " + var-name ;

CreateWindow {
W="300"
H="200"
TITLE="AUTH Example"
RESIZABLE="false"
TRAYICON="false"
EXTENSIONS="true"
}

Text {
X="20"
Y="20"
W="250"
H="25"
TEXT="Hello from AUTH!"
}

Button {
X="20"
Y="60"
W="120"
H="30"
TEXT="Click me"
}
    )

    FileAppend, %AUTHText%, %AUTHFile%, UTF-8
}


if (A_Args.MaxIndex() >= 1)
{
    AuthPath := A_Args[1]

    if FileExist(AuthPath)
    {
        RunAuthFile(AuthPath)
        ExitApp
    }
}


Gui, +AlwaysOnTop +HwndMainHwnd +E0x400
Gui, Font, s10, Tahoma

Gui, Add, Text, x100 y8 w100 Center, Options
Gui, Add, Button, x20 y32 w120 h25 gOpenNotepad, Open Notepad
Gui, Add, Button, x160 y32 w120 h25 gCreateAuth, Create .auth
Gui, Add, Button, x20 y62 w260 h25 gRunAuth, Run .auth

Gui, Show, w300 h100, TinyRavProgram
Return


OpenNotepad:

Run, notepad.exe
Return


CreateAuth:

RegDelete, HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\FileExts\.auth\UserChoice

AuthRoot := "HKEY_CURRENT_USER\Software\Classes"
ExtKey := AuthRoot . "\.auth"
ProgID := AuthRoot . "\xrip.authfile"

RegWrite, REG_SZ, %ExtKey%, , xrip.authfile

if ErrorLevel
{
    MsgBox, 16, TinyRavProgram, Failed to register .auth.
    Return
}


RegWrite, REG_SZ, %ProgID%, , XRIP AUTH File

if ErrorLevel
{
    MsgBox, 16, TinyRavProgram, Failed to register AUTH file type.
    Return
}


if (A_IsCompiled)
{
    AuthCommand := """" . A_ScriptFullPath . """ ""%1%"""
}
else
{
    AuthCommand := """" . A_AhkPath . """ """ . A_ScriptFullPath . """ ""%1%"""
}


RegWrite, REG_SZ, %ProgID%\shell\open\command, , %AuthCommand%

if ErrorLevel
{
    MsgBox, 16, TinyRavProgram, Failed to register AUTH open command.
    Return
}


IconPath := A_WinDir . "\System32\SHELL32.dll,-70"

RegWrite, REG_SZ, %ProgID%\DefaultIcon, , %IconPath%

if ErrorLevel
{
    MsgBox, 16, TinyRavProgram, Failed to register icon.
    Return
}


RegWrite, REG_SZ, %ProgID%\Content Type, , text/plain

DllCall("Shell32\SHChangeNotify", "UInt", 0x08000000, "UInt", 0, "Ptr", 0, "Ptr", 0)


FileSelectFile, SavePath, S16, %A_Desktop%\example.auth, Save AUTH file, AUTH Files (*.auth)

if ErrorLevel
    Return


if (SubStr(SavePath, -4) != ".auth")
    SavePath := SavePath . ".auth"


AuthText =
(
; AUTH program

var x = 10 ;
var y = 5 ;
var amogus = sus ;
var name = "RavKo" ;

say var-x + var-y ;
say var-amogus ;
say "Hello " + var-name ;
)

FileAppend, %AuthText%, %SavePath%, UTF-8


if ErrorLevel
{
    MsgBox, 16, TinyRavProgram, Failed to create AUTH file.
    Return
}


if !FileExist(SavePath)
{
    MsgBox, 16, TinyRavProgram, AUTH file was not created.
    Return
}


MsgBox, 64, TinyRavProgram, AUTH file created successfully.`n`n%SavePath%
Return


RunAuth:

FileSelectFile, AuthPath, 3,, Run AUTH file, AUTH Files (*.auth)

if ErrorLevel
    Return

RunAuthFile(AuthPath)
Return


RunAuthFile(FilePath)
{
    FileRead, Source, %FilePath%

    if ErrorLevel
    {
        MsgBox, 16, AUTH Error, Could not read AUTH file.
        Return
    }


    StringReplace, Source, Source, `r`n, `n, All
    StringReplace, Source, Source, `r, `n, All


    Vars := Object()
    WindowOpen := false
    Extensions := false

    CurrentBlock := ""
    BlockText := ""


    Loop, Parse, Source, `n
    {
        Line := Trim(A_LoopField)

        if (A_Index = 1)
            Line := RegExReplace(Line, "^\x{FEFF}")

        if (Line = "")
            Continue

        if (SubStr(Line, 1, 1) = ";")
            Continue


        if (CurrentBlock != "")
        {
            if (Line = "}")
            {
                if (CurrentBlock = "CreateWindow")
                {
                    W := GetProperty(BlockText, "W", "300")
                    H := GetProperty(BlockText, "H", "200")
                    Title := GetProperty(BlockText, "TITLE", "AUTH Program")
                    Resize := GetProperty(BlockText, "RESIZABLE", "false")
                    Extensions := GetProperty(BlockText, "EXTENSIONS", "false")

                    Gui, 2:Destroy
                    Gui, 2:+AlwaysOnTop

                    if IsTrue(Resize)
                        Gui, 2:+Resize

                    Gui, 2:Show, w%W% h%H%, %Title%

                    WindowOpen := true
                }
                else if (CurrentBlock = "Text")
                {
                    if !WindowOpen
                    {
                        MsgBox, 16, AUTH Error, Text requires CreateWindow.
                        Return
                    }

                    if !IsTrue(Extensions)
                    {
                        MsgBox, 16, AUTH Error, Text requires EXTENSIONS="true".
                        Return
                    }

                    X := GetProperty(BlockText, "X", "10")
                    Y := GetProperty(BlockText, "Y", "10")
                    W := GetProperty(BlockText, "W", "200")
                    H := GetProperty(BlockText, "H", "25")
                    Text := GetProperty(BlockText, "TEXT", "")

                    Gui, 2:Add, Text, x%X% y%Y% w%W% h%H%, %Text%
                }
                else if (CurrentBlock = "Button")
                {
                    if !WindowOpen
                    {
                        MsgBox, 16, AUTH Error, Button requires CreateWindow.
                        Return
                    }

                    if !IsTrue(Extensions)
                    {
                        MsgBox, 16, AUTH Error, Button requires EXTENSIONS="true".
                        Return
                    }

                    X := GetProperty(BlockText, "X", "10")
                    Y := GetProperty(BlockText, "Y", "50")
                    W := GetProperty(BlockText, "W", "100")
                    H := GetProperty(BlockText, "H", "30")
                    Text := GetProperty(BlockText, "TEXT", "Button")

                    Gui, 2:Add, Button, x%X% y%Y% w%W% h%H% gAuthButton, %Text%
                }

                CurrentBlock := ""
                BlockText := ""
                Continue
            }


            if (BlockText = "")
                BlockText := Line
            else
                BlockText := BlockText . "`n" . Line

            Continue
        }


        if RegExMatch(Line, "i)^CreateWindow\s*\{")
        {
            CurrentBlock := "CreateWindow"
            BlockText := ""
            Continue
        }


        if RegExMatch(Line, "i)^Text\s*\{")
        {
            CurrentBlock := "Text"
            BlockText := ""
            Continue
        }


        if RegExMatch(Line, "i)^Button\s*\{")
        {
            CurrentBlock := "Button"
            BlockText := ""
            Continue
        }


        if RegExMatch(Line, "i)^var\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*;$", M)
        {
            Name := M1
            Value := M2

            Value := ResolveValue(Value, Vars)

            if (Value = "__ERROR__")
            {
                MsgBox, 16, AUTH Error, Invalid variable expression.`n`n%Line%
                Return
            }

            Vars[Name] := Value
            Continue
        }


        if RegExMatch(Line, "i)^say\s+(.+?)\s*;$", M)
        {
            Value := M1
            Value := ResolveExpression(Value, Vars)

            if (Value = "__ERROR__")
            {
                MsgBox, 16, AUTH Error, Invalid say expression.`n`n%Line%
                Return
            }

            MsgBox, 64, AUTH, %Value%
            Continue
        }


        MsgBox, 16, AUTH Error, Unknown command.`n`n%Line%
        Return
    }


    if (CurrentBlock != "")
    {
        MsgBox, 16, AUTH Error, Missing closing brace.
        Return
    }
}


ResolveValue(Value, Vars)
{
    Value := Trim(Value)


    if (StrLen(Value) >= 2)
    {
        if (SubStr(Value, 1, 1) = """")
        {
            if (SubStr(Value, StrLen(Value), 1) != """")
                Return "__ERROR__"

            Return SubStr(Value, 2, StrLen(Value) - 2)
        }
    }


    if RegExMatch(Value, "i)^var-([A-Za-z_][A-Za-z0-9_]*)$", M)
    {
        if !Vars.HasKey(M1)
            Return "__ERROR__"

        Return Vars[M1]
    }


    if RegExMatch(Value, "^-?[0-9]+(?:\.[0-9]+)?$")
        Return Value + 0


    if RegExMatch(Value, "^[A-Za-z_][A-Za-z0-9_]*$")
        Return Value


    Return "__ERROR__"
}


ResolveExpression(Expression, Vars)
{
    Expression := Trim(Expression)

    Parts := Object()
    Current := ""
    InQuotes := false
    Count := 0


    Loop, Parse, Expression
    {
        C := A_LoopField


        if (C = """")
        {
            InQuotes := !InQuotes
            Current := Current . C
            Continue
        }


        if (!InQuotes && C = "+")
        {
            Count++
            Parts[Count] := Trim(Current)
            Current := ""
            Continue
        }


        Current := Current . C
    }


    if InQuotes
        Return "__ERROR__"


    Count++
    Parts[Count] := Trim(Current)


    Result := ""
    AllNumeric := true


    Loop, %Count%
    {
        Part := Parts[A_Index]
        Value := ResolveValue(Part, Vars)


        if (Value = "__ERROR__")
            Return "__ERROR__"


        if !RegExMatch(Value, "^-?[0-9]+(?:\.[0-9]+)?$")
            AllNumeric := false


        if (A_Index = 1)
        {
            Result := Value
            Continue
        }


        if AllNumeric
            Result := Result + Value
        else
            Result := Result . Value
    }


    Return Result
}


GetProperty(Data, Name, Default)
{
    Pattern := "i)^" . Name . "\s*=\s*""([^""]*)""\s*$"


    Loop, Parse, Data, `n
    {
        Line := Trim(A_LoopField)


        if RegExMatch(Line, Pattern, M)
            Return M1
    }


    Return Default
}


IsTrue(Value)
{
    Value := Trim(Value)


    if (Value = "true")
        Return true

    if (Value = "TRUE")
        Return true

    if (Value = "True")
        Return true

    if (Value = "1")
        Return true


    Return false
}


AuthButton:

MsgBox, 64, AUTH, Button clicked!
Return


2GuiClose:

Gui, 2:Destroy
Return


GuiClose:

ExitApp